def check_login(usuario, senha):
    return usuario == "admin" and senha == "senha123"
